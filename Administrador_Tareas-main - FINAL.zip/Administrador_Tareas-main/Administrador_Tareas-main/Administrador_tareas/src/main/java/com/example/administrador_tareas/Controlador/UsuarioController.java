package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.UsuarioDAO;
import com.example.administrador_tareas.Dao.AlertaDAO;
import com.example.administrador_tareas.Modelo.Usuario;
import com.example.administrador_tareas.Modelo.Alerta;
import com.example.administrador_tareas.Utilidades.EmailService;
import com.example.administrador_tareas.Utilidades.EmailTemplates;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 *
 * @author Carlos Arroyo
 */

public class UsuarioController {

    @FXML
    private TextField nombreField;

    @FXML
    private TextField correoField;

    @FXML
    private PasswordField contrasenaField;

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @FXML
    private void handleLogin() {
        String nombre = nombreField.getText().trim();
        String contrasena = contrasenaField.getText().trim();

        if (nombre.isEmpty() || contrasena.isEmpty()) {
            mostrarAlerta("Campos obligatorios", "Por favor, completa todos los campos.", Alert.AlertType.WARNING);
            System.out.println("⚠️ Campos vacíos. No se puede continuar con el login.");
            return;
        }

        Usuario usuario = null;
        try {
            usuario = usuarioDAO.login(nombre, contrasena).orElse(null);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (usuario != null) {
            mostrarAlerta("✅ Acceso permitido", "Bienvenido " + nombre, Alert.AlertType.INFORMATION);
            System.out.println("✅ Usuario encontrado en la base de datos: " + usuario);

            // Process unsent notifications asynchronously
            procesarNotificacionesPendientes(usuario);

            try {
                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource("/com/example/administrador_tareas/Vista/Tareas.fxml"));
                Parent root = loader.load();

                TareaController controller = loader.getController();
                controller.setUsuario(usuario);

                Stage nuevaVentana = new Stage();
                nuevaVentana.setTitle("Gestor de Tareas");
                nuevaVentana.setScene(new Scene(root));
                nuevaVentana.show();

                ((Stage) nombreField.getScene().getWindow()).close();

            } catch (IOException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo cargar la vista de tareas.", Alert.AlertType.ERROR);
            }
        } else {
            mostrarAlerta("❌ Acceso denegado", "Usuario no registrado o datos incorrectos.", Alert.AlertType.ERROR);
            System.out.println("❌ Usuario no encontrado o credenciales incorrectas.");
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null); // <- Oculta el encabezado para que se vea más limpio
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void abrirVentanaRegistro() {

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/administrador_tareas/Vista/registro.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Registro de Usuario");
            stage.setScene(new Scene(root));
            stage.show();
            Stage ventanaLogin = (Stage) nombreField.getScene().getWindow();
            ventanaLogin.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void procesarNotificacionesPendientes(Usuario usuario) {
        new Thread(() -> {
            try {
                AlertaDAO alertaDAO = new AlertaDAO();
                java.util.List<Alerta> noEnviadas = alertaDAO.listarNoEnviadas(usuario.getIdUsuario());

                if (!noEnviadas.isEmpty()) {
                    System.out.println("📧 Enviando " + noEnviadas.size() + " notificaciones pendientes...");
                    for (Alerta alerta : noEnviadas) {
                        String asunto = EmailTemplates.obtenerAsunto(alerta.getTipoAlerta());
                        String cuerpo = EmailTemplates.generarHtmlNotificacion(asunto, alerta.getMensaje(),
                                alerta.getTipoAlerta());
                        EmailService.enviarCorreo(usuario.getCorreo(), asunto, cuerpo);
                        alertaDAO.marcarComoEnviada(alerta.getIdAlerta());

                        // Small delay to avoid spamming SMTP server too fast
                        Thread.sleep(1000);
                    }
                    System.out.println("✅ Notificaciones pendientes enviadas.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
