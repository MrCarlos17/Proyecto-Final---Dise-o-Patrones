package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Modelo.Equipo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.SQLException;

/**
 *
 * @author Carlos Arroyo
 */

public class NuevoEquipoController {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextArea txtDescripcion;

    private Equipo equipo;
    private EquipoDAO equipoDAO;
    private boolean esEdicion = false;

    @FXML
    public void initialize() {
        equipoDAO = new EquipoDAO();
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
        this.esEdicion = true;
        txtNombre.setText(equipo.getNombre());
        txtDescripcion.setText(equipo.getDescripcion());
    }

    @FXML
    private void handleGuardar(ActionEvent event) {
        if (validarCampos()) {
            if (!esEdicion) {
                equipo = new Equipo();
            }
            equipo.setNombre(txtNombre.getText());
            equipo.setDescripcion(txtDescripcion.getText());

            try {
                if (esEdicion) {
                    equipoDAO.actualizar(equipo);
                } else {
                    equipoDAO.insertar(equipo);
                }
                cerrarVentana();
            } catch (SQLException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo guardar el equipo: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCancelar(ActionEvent event) {
        cerrarVentana();
    }

    private boolean validarCampos() {
        if (txtNombre.getText().isEmpty()) {
            mostrarAlerta("Campos requeridos", "Por favor ingrese el nombre del equipo.");
            return false;
        }
        return true;
    }

    private void cerrarVentana() {
        Stage stage = (Stage) txtNombre.getScene().getWindow();
        stage.close();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
