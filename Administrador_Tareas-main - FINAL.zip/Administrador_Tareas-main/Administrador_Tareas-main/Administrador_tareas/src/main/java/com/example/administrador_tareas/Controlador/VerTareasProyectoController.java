package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Dao.TareaDAO;

import com.example.administrador_tareas.Modelo.Proyecto;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Carlos Arroyo
 */

public class VerTareasProyectoController {

    @FXML
    private Label lblProyectoNombre;
    @FXML
    private VBox vboxPendientes;
    @FXML
    private VBox vboxProgreso;
    @FXML
    private VBox vboxCompletadas;

    private Proyecto proyecto;
    private Usuario usuarioActual;
    private TareaDAO tareaDAO = new TareaDAO();
    private EquipoDAO equipoDAO = new EquipoDAO();

    public void setProyecto(Proyecto proyecto) {
        this.proyecto = proyecto;
        lblProyectoNombre.setText(proyecto.getNombre());
        cargarTareas();
    }

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
    }

    private void cargarTareas() {
        vboxPendientes.getChildren().clear();
        vboxProgreso.getChildren().clear();
        vboxCompletadas.getChildren().clear();

        List<Tarea> tareas = tareaDAO.listarPorProyecto(proyecto.getIdProyecto());

        for (Tarea tarea : tareas) {
            VBox card = crearTarjetaTarea(tarea);
            switch (tarea.getEstado()) {
                case PENDING:
                    vboxPendientes.getChildren().add(card);
                    break;
                case IN_PROGRESS:
                    vboxProgreso.getChildren().add(card);
                    break;
                case COMPLETED:
                    vboxCompletadas.getChildren().add(card);
                    break;
                default:
                    break;
            }
        }
    }

    private VBox crearTarjetaTarea(Tarea tarea) {
        VBox card = new VBox();
        card.setStyle(
                "-fx-background-color: white; -fx-padding: 10; -fx-background-radius: 5; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 3, 0, 0, 1);");
        card.setSpacing(5);

        Label title = new Label(tarea.getTitulo());
        title.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: #1E293B;");
        title.setWrapText(true);

        HBox tags = new HBox(5);
        Label priorityLabel = new Label(tarea.getPrioridad().name());
        priorityLabel.setStyle(
                "-fx-background-color: #E2E8F0; -fx-padding: 2 6; -fx-background-radius: 4; -fx-font-size: 10px; -fx-text-fill: #475569;");

        Label dateLabel = new Label();
        if (tarea.getFechaLimite() != null) {
            dateLabel.setText(tarea.getFechaLimite().format(DateTimeFormatter.ofPattern("dd MMM")));
            dateLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #64748B;");
        }

        tags.getChildren().addAll(priorityLabel, dateLabel);

        // Assigned users section
        HBox assignedBox = new HBox(3);
        List<Usuario> asignados = tareaDAO.obtenerAsignados(tarea.getIdTarea());
        for (Usuario u : asignados) {
            javafx.scene.Node userNode;
            if (u.getRutaImagen() != null && !u.getRutaImagen().isEmpty()
                    && new java.io.File(u.getRutaImagen()).exists()) {
                javafx.scene.shape.Circle avatar = new javafx.scene.shape.Circle(10);
                avatar.setFill(new javafx.scene.paint.ImagePattern(
                        new javafx.scene.image.Image(new java.io.File(u.getRutaImagen()).toURI().toString())));
                userNode = avatar;
            } else {
                Label userLabel = new Label(u.getNombre().substring(0, 1).toUpperCase());
                userLabel.setStyle(
                        "-fx-background-color: #3B82F6; -fx-text-fill: white; -fx-padding: 2 5; -fx-background-radius: 10; -fx-font-size: 10px; -fx-min-width: 20px; -fx-alignment: center;");
                userNode = userLabel;
            }
            assignedBox.getChildren().add(userNode);
        }

        // Assign button
        Button btnAsignar = new Button("+");
        btnAsignar.setStyle(
                "-fx-background-color: transparent; -fx-text-fill: #64748B; -fx-font-size: 14px; -fx-padding: 0;");
        btnAsignar.setOnAction(e -> handleAsignarUsuario(tarea));
        assignedBox.getChildren().add(btnAsignar);

        card.getChildren().addAll(title, tags, assignedBox);

        return card;
    }

    @FXML
    private void handleAnadirTarea() {
        try {
            if (usuarioActual == null) {
                return;
            }
            List<Tarea> tareasDisponibles = tareaDAO.listarTareasSinProyecto(usuarioActual.getIdUsuario());

            if (tareasDisponibles.isEmpty()) {
                javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                        javafx.scene.control.Alert.AlertType.INFORMATION);
                alert.setTitle("Sin Tareas");
                alert.setHeaderText(null);
                alert.setContentText("Actualmente no hay tareas pendientes creadas, añade una");
                alert.showAndWait();
                return;
            }

            // Wrapper for Tarea to display title in ChoiceDialog
            class TareaWrapper {
                Tarea t;

                TareaWrapper(Tarea t) {
                    this.t = t;
                }

                @Override
                public String toString() {
                    return t.getTitulo();
                }
            }

            List<TareaWrapper> wrappers = tareasDisponibles.stream().map(TareaWrapper::new).toList();

            ChoiceDialog<TareaWrapper> dialog = new ChoiceDialog<>(wrappers.get(0), wrappers);
            dialog.setTitle("Añadir Tarea al Proyecto");
            dialog.setHeaderText("Selecciona una tarea para añadir a este proyecto");
            dialog.setContentText("Tarea:");

            // Customize button text
            Button okButton = (Button) dialog.getDialogPane().lookupButton(javafx.scene.control.ButtonType.OK);
            okButton.setText("Guardar");

            Optional<TareaWrapper> result = dialog.showAndWait();
            result.ifPresent(wrapper -> {
                try {
                    tareaDAO.asignarProyecto(wrapper.t.getIdTarea(), proyecto.getIdProyecto());
                    cargarTareas();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void handleAsignarUsuario(Tarea tarea) {
        if (proyecto.getIdEquipo() == null) {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.WARNING);
            alert.setTitle("Proyecto sin Equipo");
            alert.setHeaderText(null);
            alert.setContentText(
                    "Este proyecto no tiene un equipo asignado. Debes asignar un equipo al proyecto para poder asignar tareas a usuarios.");
            alert.showAndWait();
            return;
        }

        List<Usuario> candidatos = equipoDAO.listarMiembros(proyecto.getIdEquipo());

        if (candidatos.isEmpty()) {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.INFORMATION);
            alert.setTitle("Sin Miembros");
            alert.setHeaderText(null);
            alert.setContentText("El equipo asignado no tiene miembros.");
            alert.showAndWait();
            return;
        }

        // Wrapper for Usuario to display name in ChoiceDialog
        class UsuarioWrapper {
            Usuario u;

            UsuarioWrapper(Usuario u) {
                this.u = u;
            }

            @Override
            public String toString() {
                return u.getNombre() + " (" + u.getCorreo() + ")";
            }
        }

        List<UsuarioWrapper> wrappers = candidatos.stream().map(UsuarioWrapper::new).toList();

        ChoiceDialog<UsuarioWrapper> dialog = new ChoiceDialog<>(wrappers.get(0), wrappers);
        dialog.setTitle("Asignar Usuario");
        dialog.setHeaderText("Selecciona un usuario para asignar a la tarea: " + tarea.getTitulo());
        dialog.setContentText("Usuario:");

        Optional<UsuarioWrapper> result = dialog.showAndWait();
        result.ifPresent(wrapper -> {
            try {
                tareaDAO.asignarUsuario(tarea.getIdTarea(), wrapper.u.getIdUsuario());
                cargarTareas(); // Refresh to show the new assignee
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }
}
