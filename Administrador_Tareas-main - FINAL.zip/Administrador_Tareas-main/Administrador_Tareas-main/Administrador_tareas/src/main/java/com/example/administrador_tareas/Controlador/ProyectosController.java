package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.ProyectoDAO;
import com.example.administrador_tareas.Modelo.Proyecto;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 *
 * @author Carlos Arroyo
 */

public class ProyectosController {

    @FXML
    private TableView<Proyecto> tablaProyectos;
    @FXML
    private TableColumn<Proyecto, String> colNombre;
    @FXML
    private TableColumn<Proyecto, String> colCodigo;
    @FXML
    private TableColumn<Proyecto, String> colEstado;
    @FXML
    private TableColumn<Proyecto, String> colEquipo;
    @FXML
    private TableColumn<Proyecto, String> colFecha;
    @FXML
    private TableColumn<Proyecto, Void> colAcciones;

    private Usuario usuarioActual;
    private ProyectoDAO proyectoDAO;

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        this.proyectoDAO = new ProyectoDAO();
        inicializarTabla();
        cargarProyectos();
    }

    private void inicializarTabla() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colEstado.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEstado().name()));
        colEquipo.setCellValueFactory(cellData -> {
            String nombreEquipo = cellData.getValue().getNombreEquipo();
            return new SimpleStringProperty(nombreEquipo != null ? nombreEquipo : "Sin Equipo");
        });
        colFecha.setCellValueFactory(cellData -> new SimpleStringProperty(
                cellData.getValue().getFechaCreacion().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));

        colAcciones.setCellFactory(param -> new javafx.scene.control.TableCell<>() {
            private final javafx.scene.control.Button btnEditar = new javafx.scene.control.Button("Editar");
            private final javafx.scene.control.Button btnVerTareas = new javafx.scene.control.Button("Ver Tareas");

            {
                btnEditar.getStyleClass().add("button-secondary-small");
                btnEditar.setOnAction(event -> {
                    Proyecto proyecto = getTableView().getItems().get(getIndex());
                    handleEditarProyecto(proyecto);
                });

                btnVerTareas.getStyleClass().add("button-primary-small"); // Assuming or use default
                btnVerTareas.setStyle("-fx-background-color: #3B82F6; -fx-text-fill: white; -fx-font-size: 11px;");
                btnVerTareas.setOnAction(event -> {
                    Proyecto proyecto = getTableView().getItems().get(getIndex());
                    handleVerTareas(proyecto);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(5, btnVerTareas, btnEditar);
                    setGraphic(buttons);
                }
            }
        });
    }

    private void cargarProyectos() {
        List<Proyecto> proyectos = proyectoDAO.listarProyectos();
        tablaProyectos.setItems(FXCollections.observableArrayList(proyectos));
    }

    private void handleEditarProyecto(Proyecto proyecto) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/NuevoProyecto.fxml"));
            javafx.scene.Parent root = loader.load();

            NuevoProyectoController controller = loader.getController();
            controller.setProyecto(proyecto);

            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.initModality(javafx.stage.Modality.WINDOW_MODAL);
            stage.initOwner(tablaProyectos.getScene().getWindow());
            stage.setTitle("Editar Proyecto");
            stage.setScene(new javafx.scene.Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

            cargarProyectos();

        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }

    private void handleVerTareas(Proyecto proyecto) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/VerTareasProyecto.fxml"));
            javafx.scene.Parent root = loader.load();

            VerTareasProyectoController controller = loader.getController();
            controller.setProyecto(proyecto);
            controller.setUsuario(usuarioActual);

            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.initModality(javafx.stage.Modality.WINDOW_MODAL);
            stage.initOwner(tablaProyectos.getScene().getWindow());
            stage.setTitle("Tareas del Proyecto: " + proyecto.getNombre());
            stage.setScene(new javafx.scene.Scene(root, 800, 500));
            stage.show();

        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleNuevoProyecto(ActionEvent event) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/NuevoProyecto.fxml"));
            javafx.scene.Parent root = loader.load();

            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.initModality(javafx.stage.Modality.WINDOW_MODAL);
            stage.initOwner(tablaProyectos.getScene().getWindow());
            stage.setTitle("Nuevo Proyecto");
            stage.setScene(new javafx.scene.Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

            NuevoProyectoController controller = loader.getController();
            if (controller.getNuevoProyecto() != null) {
                cargarProyectos();
            }

        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
}
