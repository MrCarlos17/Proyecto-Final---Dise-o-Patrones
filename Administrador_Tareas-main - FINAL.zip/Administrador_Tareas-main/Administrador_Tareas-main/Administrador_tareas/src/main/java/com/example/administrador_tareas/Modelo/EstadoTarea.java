package com.example.administrador_tareas.Modelo;

/**
 *
 * @author Carlos Arroyo
 */

public enum EstadoTarea {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    ARCHIVED,
    CANCELED
}
