package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.ArchivoAdjuntoDAO;
import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Modelo.ArchivoAdjunto;
import com.example.administrador_tareas.Modelo.PrioridadTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author Carlos Arroyo
 */

public class EditarTareaController {
    @FXML
    private TextField txtTitulo;
    @FXML
    private TextArea txtDescripcion;
    @FXML
    private DatePicker dpFechaLimite;
    @FXML
    private ComboBox<PrioridadTarea> cmbPrioridad;
    @FXML
    private ListView<File> listViewArchivos;
    @FXML
    private Button btnAgregarArchivo, btnEliminarArchivo;

    private Tarea tarea;
    private boolean guardado = false;
    private List<File> archivos = new ArrayList<>();

    @FXML
    public void initialize() {
        cmbPrioridad.getItems().setAll(PrioridadTarea.values());
    }

    public void setTarea(Tarea tarea) {
        this.tarea = tarea;
        txtTitulo.setText(tarea.getTitulo());
        txtDescripcion.setText(tarea.getDescripcion());
        if (tarea.getFechaLimite() != null) {
            dpFechaLimite.setValue(tarea.getFechaLimite().toLocalDate());
        }
        cmbPrioridad.setValue(tarea.getPrioridad());

        // Cargar archivos adjuntos anteriores desde BD
        ArchivoAdjuntoDAO adjDAO = new ArchivoAdjuntoDAO();
        try {
            archivos = adjDAO.listarPorTarea(tarea.getIdTarea())
                    .stream()
                    .map(adj -> new File(adj.getRutaArchivo()))
                    .collect(Collectors.toList());
            listViewArchivos.getItems().setAll(archivos);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAgregarArchivo(ActionEvent e) {
        FileChooser chooser = new FileChooser();
        List<File> nuevos = chooser.showOpenMultipleDialog(btnAgregarArchivo.getScene().getWindow());
        if (nuevos != null && archivos.addAll(nuevos)) {
            listViewArchivos.getItems().setAll(archivos);
        }
    }

    @FXML
    private void handleEliminarArchivo(ActionEvent e) {
        File sel = listViewArchivos.getSelectionModel().getSelectedItem();
        if (sel != null && archivos.remove(sel)) {
            listViewArchivos.getItems().setAll(archivos);
        }
    }

    @FXML
    private void handleGuardar(ActionEvent e) {
        if (txtTitulo.getText().trim().isEmpty() ||
                txtDescripcion.getText().trim().isEmpty() ||
                dpFechaLimite.getValue() == null ||
                cmbPrioridad.getValue() == null) {
            new Alert(Alert.AlertType.WARNING, "Completa todos los campos").showAndWait();
            return;
        }

        tarea.setTitulo(txtTitulo.getText().trim());
        tarea.setDescripcion(txtDescripcion.getText().trim());
        tarea.setFechaLimite(dpFechaLimite.getValue().atStartOfDay());
        tarea.setPrioridad(cmbPrioridad.getValue());
        tarea.setFechaActualizacion(java.time.LocalDateTime.now());
        guardado = true;

        // Guardar cambios en BD
        try {
            new TareaDAO().actualizar(tarea);
            ArchivoAdjuntoDAO adjDAO = new ArchivoAdjuntoDAO();
            adjDAO.eliminarPorTarea(tarea.getIdTarea());

            for (File f : archivos) {
                String tipo = f.getName().toLowerCase().matches(".*\\.(png|jpg|jpeg|gif)$") ? "imagen" : "documento";
                boolean esImagen = tipo.equals("imagen");

                ArchivoAdjunto adj = new ArchivoAdjunto();
                adj.setIdTarea(tarea.getIdTarea());
                adj.setNombreArchivo(f.getName());
                adj.setRutaArchivo(f.getAbsolutePath());
                adj.setTipoMime(tipo);
                adj.setEsImagen(esImagen);
                adj.setSubidoPor(tarea.getCreadoPor()); // Assuming creator is uploader for now

                adjDAO.insertar(adj);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ((Stage) txtTitulo.getScene().getWindow()).close();
    }

    @FXML
    private void handleCancelar(ActionEvent e) {
        ((Stage) txtTitulo.getScene().getWindow()).close();
    }

    public boolean isGuardado() {
        return guardado;
    }
}
