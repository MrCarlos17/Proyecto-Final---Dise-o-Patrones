package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.PrioridadTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Carlos Arroyo
 */

public class TareaDAO {

    public Long insertar(Tarea tarea) throws SQLException {
        String sql = "INSERT INTO tareas " +
                "(id_proyecto, titulo, descripcion, prioridad, estado, fecha_creacion, fecha_limite, creado_por, eliminado) "
                +
                "VALUES (?, ?, ?, ?::prioridad_tarea_enum, ?::estado_tarea_enum, NOW(), ?, ?, FALSE)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            if (tarea.getIdProyecto() != null)
                ps.setLong(1, tarea.getIdProyecto());
            else
                ps.setNull(1, Types.BIGINT);

            ps.setString(2, tarea.getTitulo());
            ps.setString(3, tarea.getDescripcion());
            ps.setString(4, tarea.getPrioridad() != null ? tarea.getPrioridad().name() : PrioridadTarea.MEDIUM.name());
            ps.setString(5, tarea.getEstado() != null ? tarea.getEstado().name() : EstadoTarea.PENDING.name());

            if (tarea.getFechaLimite() != null) {
                ps.setTimestamp(6, Timestamp.valueOf(tarea.getFechaLimite()));
            } else {
                ps.setNull(6, Types.TIMESTAMP);
            }

            ps.setLong(7, tarea.getCreadoPor());

            int filas = ps.executeUpdate();
            if (filas == 0)
                throw new SQLException("No se pudo insertar la tarea");

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    Long idGenerado = rs.getLong(1);
                    tarea.setIdTarea(idGenerado);
                    return idGenerado;
                }
            }
        }
        return -1L;
    }

    public boolean actualizar(Tarea tarea) throws SQLException {
        String sql = "UPDATE tareas SET titulo = ?, descripcion = ?, fecha_limite = ?, prioridad = ?::prioridad_tarea_enum "
                +
                "WHERE id_tarea = ? AND eliminado = FALSE";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tarea.getTitulo());
            ps.setString(2, tarea.getDescripcion());
            if (tarea.getFechaLimite() != null) {
                ps.setTimestamp(3, Timestamp.valueOf(tarea.getFechaLimite()));
            } else {
                ps.setNull(3, Types.TIMESTAMP);
            }
            ps.setString(4, tarea.getPrioridad().name());
            ps.setLong(5, tarea.getIdTarea());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean actualizarEstado(Long idTarea, EstadoTarea nuevoEstado) throws SQLException {
        String sql;
        if (nuevoEstado == EstadoTarea.COMPLETED) {
            sql = "UPDATE tareas SET estado = ?::estado_tarea_enum, fecha_completada = NOW() WHERE id_tarea = ?";
        } else {
            sql = "UPDATE tareas SET estado = ?::estado_tarea_enum, fecha_completada = NULL WHERE id_tarea = ?";
        }

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado.name());
            ps.setLong(2, idTarea);

            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminarLogico(Long idTarea) throws SQLException {
        String sql = "UPDATE tareas SET eliminado = TRUE WHERE id_tarea = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idTarea);
            return ps.executeUpdate() > 0;
        }
    }

    public List<Tarea> listarPorProyecto(Long idProyecto) {
        String sql = "SELECT * FROM tareas WHERE id_proyecto = ? AND eliminado = FALSE ORDER BY fecha_creacion DESC";
        List<Tarea> lista = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idProyecto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearTarea(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Tarea> listarPorUsuario(Long idUsuario) throws SQLException {
        String sql = "SELECT * FROM tareas WHERE creado_por = ? AND eliminado = FALSE ORDER BY fecha_creacion DESC";
        List<Tarea> lista = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearTarea(rs));
                }
            }
        }
        return lista;
    }

    public List<Tarea> listarArchivadasPorUsuario(Long idUsuario) throws SQLException {
        String sql = "SELECT * FROM tareas WHERE creado_por = ? AND estado = 'ARCHIVED' AND eliminado = FALSE ORDER BY fecha_creacion DESC";
        List<Tarea> lista = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearTarea(rs));
                }
            }
        }
        return lista;
    }

    public Optional<Tarea> buscarPorId(Long idTarea) throws SQLException {
        String sql = "SELECT * FROM tareas WHERE id_tarea = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idTarea);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearTarea(rs));
                }
            }
        }
        return Optional.empty();
    }

    public int contarPorEstado(Long idUsuario, EstadoTarea estado) {
        String sql = "SELECT COUNT(*) FROM tareas WHERE creado_por = ? AND estado = ?::estado_tarea_enum AND eliminado = FALSE";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            ps.setString(2, estado.name());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next())
                    return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarTotal(Long idUsuario) {
        String sql = "SELECT COUNT(*) FROM tareas WHERE creado_por = ? AND eliminado = FALSE";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next())
                    return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarVencidas(Long idUsuario) {
        String sql = "SELECT COUNT(*) FROM tareas WHERE creado_por = ? AND eliminado = FALSE AND estado != 'COMPLETED' AND fecha_limite < NOW()";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next())
                    return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public java.util.Map<String, Integer> contarPorPrioridad(Long idUsuario) {
        String sql = "SELECT prioridad, COUNT(*) FROM tareas WHERE creado_por = ? AND eliminado = FALSE GROUP BY prioridad";
        java.util.Map<String, Integer> stats = new java.util.HashMap<>();
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    stats.put(rs.getString(1), rs.getInt(2));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stats;
    }

    private Tarea mapearTarea(ResultSet rs) throws SQLException {
        Tarea t = new Tarea();
        t.setIdTarea(rs.getLong("id_tarea"));
        t.setIdProyecto(rs.getObject("id_proyecto") != null ? rs.getLong("id_proyecto") : null);
        t.setTitulo(rs.getString("titulo"));
        t.setDescripcion(rs.getString("descripcion"));
        t.setPrioridad(PrioridadTarea.valueOf(rs.getString("prioridad")));
        t.setEstado(EstadoTarea.valueOf(rs.getString("estado")));
        t.setCreadoPor(rs.getLong("creado_por"));
        t.setArchivado(rs.getBoolean("archivado"));
        t.setEliminado(rs.getBoolean("eliminado"));

        Timestamp fCreacion = rs.getTimestamp("fecha_creacion");
        if (fCreacion != null)
            t.setFechaCreacion(fCreacion.toLocalDateTime());

        Timestamp fLimite = rs.getTimestamp("fecha_limite");
        if (fLimite != null)
            t.setFechaLimite(fLimite.toLocalDateTime());

        Timestamp fComp = rs.getTimestamp("fecha_completada");
        if (fComp != null)
            t.setFechaCompletada(fComp.toLocalDateTime());

        Timestamp fAct = rs.getTimestamp("fecha_actualizacion");
        if (fAct != null)
            t.setFechaActualizacion(fAct.toLocalDateTime());

        return t;
    }

    public List<Tarea> listarTareasSinProyecto(Long idUsuario) throws SQLException {
        String sql = "SELECT * FROM tareas WHERE creado_por = ? AND id_proyecto IS NULL AND eliminado = FALSE AND estado != 'COMPLETED'::estado_tarea_enum ORDER BY fecha_creacion DESC";
        List<Tarea> lista = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearTarea(rs));
                }
            }
        }
        return lista;
    }

    public boolean asignarUsuario(Long idTarea, Long idUsuario) throws SQLException {
        String sql = "INSERT INTO tarea_asignacion (id_tarea, id_usuario, fecha_asignacion) VALUES (?, ?, NOW()) ON CONFLICT DO NOTHING";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idTarea);
            ps.setLong(2, idUsuario);
            return ps.executeUpdate() > 0;
        }
    }

    public List<com.example.administrador_tareas.Modelo.Usuario> obtenerAsignados(Long idTarea) {
        List<com.example.administrador_tareas.Modelo.Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.* FROM usuarios u JOIN tarea_asignacion ta ON u.id_usuario = ta.id_usuario WHERE ta.id_tarea = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idTarea);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    com.example.administrador_tareas.Modelo.Usuario u = new com.example.administrador_tareas.Modelo.Usuario();
                    u.setIdUsuario(rs.getLong("id_usuario"));
                    u.setNombre(rs.getString("nombre"));
                    u.setCorreo(rs.getString("correo"));
                    u.setRutaImagen(rs.getString("ruta_imagen"));
                    usuarios.add(u);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    public boolean asignarProyecto(Long idTarea, Long idProyecto) throws SQLException {
        String sql = "UPDATE tareas SET id_proyecto = ? WHERE id_tarea = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idProyecto);
            ps.setLong(2, idTarea);
            return ps.executeUpdate() > 0;
        }
    }

    public List<Tarea> listarTareasPorUsuarioYEquipo(Long idUsuario, Long idEquipo) {
        List<Tarea> lista = new ArrayList<>();
        String sql = "SELECT t.* FROM tareas t JOIN proyectos p ON t.id_proyecto = p.id_proyecto WHERE t.creado_por = ? AND p.id_equipo = ? AND t.eliminado = FALSE ORDER BY t.fecha_creacion DESC";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            ps.setLong(2, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearTarea(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
