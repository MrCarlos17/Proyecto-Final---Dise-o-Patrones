package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.AlertaDAO;
import com.example.administrador_tareas.Modelo.Alerta;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Callback;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 *
 * @author Carlos Arroyo
 */

public class NotificacionesController {

    @FXML
    private ListView<Alerta> listaNotificaciones;

    private Usuario usuarioActual;
    private AlertaDAO alertaDAO;

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        this.alertaDAO = new AlertaDAO();
        cargarNotificaciones();
    }

    private void cargarNotificaciones() {
        if (usuarioActual == null)
            return;
        List<Alerta> alertas = alertaDAO.listarPorUsuario(usuarioActual.getIdUsuario());
        listaNotificaciones.getItems().setAll(alertas);

        listaNotificaciones.setCellFactory(new Callback<>() {
            @Override
            public ListCell<Alerta> call(ListView<Alerta> param) {
                return new ListCell<>() {
                    @Override
                    protected void updateItem(Alerta item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || item == null) {
                            setText(null);
                            setGraphic(null);
                        } else {
                            VBox vbox = new VBox(5);
                            Label lblTipo = new Label(item.getTipoAlerta().name());
                            lblTipo.setStyle("-fx-font-weight: bold; -fx-font-size: 10px; -fx-text-fill: #64748B;");

                            Text txtMensaje = new Text(item.getMensaje());
                            txtMensaje.setWrappingWidth(280);

                            Label lblFecha = new Label(
                                    item.getFechaCreacion().format(DateTimeFormatter.ofPattern("dd/MM HH:mm")));
                            lblFecha.setStyle("-fx-font-size: 10px; -fx-text-fill: #94A3B8;");

                            vbox.getChildren().addAll(lblTipo, txtMensaje, lblFecha);

                            if (!item.isLeida()) {
                                vbox.setStyle(
                                        "-fx-background-color: #EFF6FF; -fx-padding: 8; -fx-background-radius: 4;");
                            } else {
                                vbox.setStyle("-fx-padding: 8;");
                            }

                            setGraphic(vbox);

                            // Mark as read on click
                            setOnMouseClicked(e -> {
                                if (!item.isLeida()) {
                                    alertaDAO.marcarComoLeida(item.getIdAlerta());
                                    item.setLeida(true);
                                    updateItem(item, false); // Refresh cell
                                }
                            });
                        }
                    }
                };
            }
        });
    }

    @FXML
    private void handleMarcarTodasLeidas() {
        if (usuarioActual == null)
            return;
        // Optimization: Add marcarTodasComoLeidas to DAO
        listaNotificaciones.getItems().forEach(alerta -> {
            if (!alerta.isLeida()) {
                alertaDAO.marcarComoLeida(alerta.getIdAlerta());
                alerta.setLeida(true);
            }
        });
        listaNotificaciones.refresh();
    }
}
