/**
 *
 * @author Carlos Arroyo
 */
module com.example.administrador_tareas {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    requires jakarta.mail;
    requires com.google.gson;
    requires java.net.http;

    opens com.example.administrador_tareas.Vista to javafx.fxml;

    exports com.example.administrador_tareas;
    exports com.example.administrador_tareas.Controlador;
    exports com.example.administrador_tareas.Modelo;
    exports com.example.administrador_tareas.Dao;

    opens com.example.administrador_tareas.Controlador to javafx.fxml;
}