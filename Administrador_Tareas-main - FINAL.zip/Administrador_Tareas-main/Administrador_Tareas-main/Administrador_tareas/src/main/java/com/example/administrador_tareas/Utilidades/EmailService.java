package com.example.administrador_tareas.Utilidades;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;

/**
 *
 * @author Carlos Arroyo
 */

public class EmailService {

    // Placeholder credentials - User must update these!
    private static final String USERNAME = "nekosaccix@gmail.com";
    private static final String PASSWORD = "ittsmjryvyjpckxp";

    public static void enviarCorreo(String destinatario, String asunto, String cuerpo) {
        if (USERNAME.equals("tu_correo@gmail.com")) {
            System.out.println("⚠️ EmailService no configurado. No se envió el correo a: " + destinatario);
            System.out.println("   Asunto: " + asunto);
            System.out.println("   Cuerpo: " + cuerpo);
            return;
        }

        Properties prop = new Properties();
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.ssl.trust", "smtp.gmail.com");

        Session session = Session.getInstance(prop, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);
            message.setContent(cuerpo, "text/html; charset=utf-8");

            Transport.send(message);

            System.out.println("✅ Correo enviado a: " + destinatario);

        } catch (MessagingException e) {
            e.printStackTrace();
            System.err.println("❌ Error al enviar correo: " + e.getMessage());
        }
    }
}
