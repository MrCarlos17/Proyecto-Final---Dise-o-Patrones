package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.UsuarioDAO;
import com.example.administrador_tareas.Modelo.Usuario;
import com.example.administrador_tareas.Utilidades.EmailValidator;
import com.example.administrador_tareas.Utilidades.EmailValidator.ValidationResult;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

/**
 *
 * @author Carlos Arroyo
 */

public class RegistroController {
    @FXML
    private Button btnSalir;
    @FXML
    private TextField nombreField;
    @FXML
    private TextField correoField;
    @FXML
    private PasswordField contrasenaField;

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @FXML
    private void handleRegistro() {
        String nombre = nombreField.getText();
        String correo = correoField.getText();
        String contrasena = contrasenaField.getText();

        if (nombre.isEmpty() || correo.isEmpty() || contrasena.isEmpty()) {
            mostrarAlerta("Campos vacíos", "Llena todos los campos.", Alert.AlertType.WARNING);
            return;
        }

        // Validate Email
        ValidationResult validation = EmailValidator.validate(correo);
        if (!validation.valid) {
            mostrarAlerta("Correo Inválido", validation.message, Alert.AlertType.ERROR);
            return;
        }

        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setCorreo(correo);
        usuario.setClave(contrasena);
        // idRol and estado will be handled by DAO defaults (or we can set them here)

        Long idRegistrado = -1L;
        try {
            idRegistrado = usuarioDAO.registrar(usuario);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (idRegistrado > 0) {
            usuario.setIdUsuario(idRegistrado); // Set the generated ID
            mostrarAlerta("Registro exitoso", "Usuario registrado correctamente.", Alert.AlertType.INFORMATION);
            try {
                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource("/com/example/administrador_tareas/Vista/Tareas.fxml"));
                Parent root = loader.load();

                // Si luego quieres pasar el usuario:
                TareaController controller = loader.getController();
                controller.setUsuario(usuario);

                Stage nuevaVentana = new Stage();
                nuevaVentana.setTitle("Gestor de Tareas");
                nuevaVentana.setScene(new Scene(root));
                nuevaVentana.show();

                // Cerrar ventana de registro
                Stage ventanaRegistro = (Stage) nombreField.getScene().getWindow();
                ventanaRegistro.close();

            } catch (IOException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo cargar la vista de tareas.", Alert.AlertType.ERROR);
            }
        } else {
            mostrarAlerta("Error", "No se pudo registrar el usuario. Intenta con otro correo.", Alert.AlertType.ERROR);
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void handleSalir(ActionEvent event) throws IOException {
        // Cierra la ventana actual
        Stage stage = (Stage) btnSalir.getScene().getWindow();
        stage.close();

        // Carga la pantalla de login
        FXMLLoader loader = new FXMLLoader(getClass()
                .getResource("/com/example/administrador_tareas/Vista/Login.fxml"));
        Parent root = loader.load();

        Stage loginStage = new Stage();
        loginStage.setTitle("Login");
        loginStage.setScene(new Scene(root));
        loginStage.show();
    }
}
