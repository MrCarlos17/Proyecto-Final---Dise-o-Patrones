package com.example.administrador_tareas;

/**
 *
 * @author Carlos Arroyo
 */

public class Launcher {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
