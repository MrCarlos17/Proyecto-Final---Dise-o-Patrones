package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.ConfiguracionNotificaciones;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;

/**
 *
 * @author Carlos Arroyo
 */

public class ConfiguracionNotificacionesDAO {

    public ConfiguracionNotificaciones obtenerPorUsuario(Long idUsuario) {
        String sql = "SELECT * FROM configuracion_notificaciones WHERE id_usuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, idUsuario);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    ConfiguracionNotificaciones config = new ConfiguracionNotificaciones();
                    config.setIdConfiguracion(rs.getLong("id_configuracion"));
                    config.setIdUsuario(rs.getLong("id_usuario"));
                    config.setRecibirEmails(rs.getBoolean("recibir_emails"));
                    config.setAlertasTareas(rs.getBoolean("alertas_tareas"));
                    config.setAlertasComentarios(rs.getBoolean("alertas_comentarios"));
                    config.setMinutosAntesVencimiento(rs.getInt("minutos_antes_vencimiento"));
                    return config;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if not found, caller should handle creation default
    }

    public void guardar(ConfiguracionNotificaciones config) {
        // Check if exists first
        if (config.getIdConfiguracion() != null) {
            actualizar(config);
        } else {
            insertar(config);
        }
    }

    private void insertar(ConfiguracionNotificaciones config) {
        String sql = "INSERT INTO configuracion_notificaciones (id_usuario, recibir_emails, alertas_tareas, alertas_comentarios, minutos_antes_vencimiento) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setLong(1, config.getIdUsuario());
            pstmt.setBoolean(2, config.isRecibirEmails());
            pstmt.setBoolean(3, config.isAlertasTareas());
            pstmt.setBoolean(4, config.isAlertasComentarios());
            pstmt.setInt(5, config.getMinutosAntesVencimiento());

            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    config.setIdConfiguracion(generatedKeys.getLong(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void actualizar(ConfiguracionNotificaciones config) {
        String sql = "UPDATE configuracion_notificaciones SET recibir_emails = ?, alertas_tareas = ?, alertas_comentarios = ?, minutos_antes_vencimiento = ? WHERE id_configuracion = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setBoolean(1, config.isRecibirEmails());
            pstmt.setBoolean(2, config.isAlertasTareas());
            pstmt.setBoolean(3, config.isAlertasComentarios());
            pstmt.setInt(4, config.getMinutosAntesVencimiento());
            pstmt.setLong(5, config.getIdConfiguracion());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
