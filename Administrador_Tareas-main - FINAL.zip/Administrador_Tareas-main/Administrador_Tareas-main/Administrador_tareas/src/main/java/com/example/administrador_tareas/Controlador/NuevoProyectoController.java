package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Dao.ProyectoDAO;
import com.example.administrador_tareas.Modelo.Equipo;
import com.example.administrador_tareas.Modelo.EstadoProyecto;
import com.example.administrador_tareas.Modelo.Proyecto;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Carlos Arroyo
 */

public class NuevoProyectoController {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtCodigo;
    @FXML
    private TextArea txtDescripcion;
    @FXML
    private ComboBox<Equipo> cmbEquipo;

    private Proyecto nuevoProyecto;
    private ProyectoDAO proyectoDAO;
    private EquipoDAO equipoDAO;

    @FXML
    public void initialize() {
        proyectoDAO = new ProyectoDAO();
        equipoDAO = new EquipoDAO();

        cmbEquipo.setConverter(new javafx.util.StringConverter<Equipo>() {
            @Override
            public String toString(Equipo equipo) {
                return equipo != null ? equipo.getNombre() : "";
            }

            @Override
            public Equipo fromString(String string) {
                return null; // Not needed for read-only combo box
            }
        });

        cargarEquipos();
    }

    private void cargarEquipos() {
        List<Equipo> equipos = equipoDAO.listarEquipos();
        cmbEquipo.getItems().addAll(equipos);
    }

    private boolean esEdicion = false;

    public void setProyecto(Proyecto proyecto) {
        this.nuevoProyecto = proyecto;
        this.esEdicion = true;
        txtNombre.setText(proyecto.getNombre());
        txtCodigo.setText(proyecto.getCodigo());
        txtDescripcion.setText(proyecto.getDescripcion());

        if (proyecto.getIdEquipo() != null) {
            for (Equipo equipo : cmbEquipo.getItems()) {
                if (equipo.getIdEquipo().equals(proyecto.getIdEquipo())) {
                    cmbEquipo.setValue(equipo);
                    break;
                }
            }
        }
    }

    @FXML
    private void handleGuardar(ActionEvent event) {
        if (validarCampos()) {
            if (!esEdicion) {
                nuevoProyecto = new Proyecto();
                nuevoProyecto.setEstado(EstadoProyecto.ACTIVO);
            }

            nuevoProyecto.setNombre(txtNombre.getText());
            nuevoProyecto.setCodigo(txtCodigo.getText());
            nuevoProyecto.setDescripcion(txtDescripcion.getText());

            if (cmbEquipo.getValue() != null) {
                nuevoProyecto.setIdEquipo(cmbEquipo.getValue().getIdEquipo());
            }

            try {
                if (esEdicion) {
                    proyectoDAO.actualizar(nuevoProyecto);
                } else {
                    proyectoDAO.insertar(nuevoProyecto);
                }
                cerrarVentana();
            } catch (SQLException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo guardar el proyecto: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCancelar(ActionEvent event) {
        cerrarVentana();
    }

    private boolean validarCampos() {
        if (txtNombre.getText().isEmpty() || txtCodigo.getText().isEmpty()) {
            mostrarAlerta("Campos requeridos", "Por favor ingrese nombre y código del proyecto.");
            return false;
        }
        return true;
    }

    private void cerrarVentana() {
        Stage stage = (Stage) txtNombre.getScene().getWindow();
        stage.close();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void handleGenerarCodigo(ActionEvent event) {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder codigo = new StringBuilder();
        java.util.Random random = new java.util.Random();
        for (int i = 0; i < 6; i++) {
            codigo.append(caracteres.charAt(random.nextInt(caracteres.length())));
        }
        txtCodigo.setText(codigo.toString());
    }

    public Proyecto getNuevoProyecto() {
        return nuevoProyecto;
    }
}
