package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.ConfiguracionNotificacionesDAO;
import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Dao.UsuarioDAO;
import com.example.administrador_tareas.Modelo.ConfiguracionNotificaciones;
import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Carlos Arroyo
 */

public class ConfiguracionController {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtCorreo;
    @FXML
    private PasswordField txtPasswordActual;
    @FXML
    private PasswordField txtPasswordNueva;
    @FXML
    private PasswordField txtPasswordConfirmar;

    @FXML
    private Label lblTareasCompletadas;
    @FXML
    private Label lblTasaExito;

    @FXML
    private CheckBox chkEmail;
    @FXML
    private CheckBox chkAlertasTareas;
    @FXML
    private CheckBox chkAlertasComentarios;
    @FXML
    private TextField txtMinutosAntes;

    private Usuario usuarioActual;
    private ConfiguracionNotificaciones configuracion;
    private ConfiguracionNotificacionesDAO configDAO;
    private UsuarioDAO usuarioDAO;
    private TareaController mainController;

    public void setMainController(TareaController mainController) {
        this.mainController = mainController;
    }

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        this.configDAO = new ConfiguracionNotificacionesDAO();
        this.usuarioDAO = new UsuarioDAO();

        cargarDatosPerfil();
        cargarConfiguracion();
        cargarEstadisticas();
    }

    @FXML
    private javafx.scene.shape.Circle avatarCircle;

    @FXML
    private void handleCambiarFoto() {
        javafx.stage.FileChooser fileChooser = new javafx.stage.FileChooser();
        fileChooser.setTitle("Seleccionar Foto de Perfil");
        fileChooser.getExtensionFilters().addAll(
                new javafx.stage.FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg"));

        java.io.File selectedFile = fileChooser.showOpenDialog(txtNombre.getScene().getWindow());

        if (selectedFile != null) {
            try {
                // Create directory if not exists
                java.nio.file.Path uploadDir = java.nio.file.Paths.get("user_images");
                if (!java.nio.file.Files.exists(uploadDir)) {
                    java.nio.file.Files.createDirectories(uploadDir);
                }

                // Copy file with unique name
                String fileName = "user_" + usuarioActual.getIdUsuario() + "_" + System.currentTimeMillis() + "_"
                        + selectedFile.getName();
                java.nio.file.Path targetPath = uploadDir.resolve(fileName);
                java.nio.file.Files.copy(selectedFile.toPath(), targetPath,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);

                // Update user and UI
                usuarioActual.setRutaImagen(targetPath.toString());
                actualizarAvatar(targetPath.toUri().toString());

                // Save to DB
                usuarioDAO.actualizar(usuarioActual);

                if (mainController != null) {
                    mainController.actualizarAvatarHeader();
                }

                mostrarAlerta(Alert.AlertType.INFORMATION, "Foto de perfil actualizada.");

            } catch (java.io.IOException | SQLException e) {
                e.printStackTrace();
                mostrarAlerta(Alert.AlertType.ERROR, "Error al guardar la imagen: " + e.getMessage());
            }
        }
    }

    private void actualizarAvatar(String imagePath) {
        if (imagePath != null && !imagePath.isEmpty()) {
            javafx.scene.image.Image img = new javafx.scene.image.Image(imagePath);
            avatarCircle.setFill(new javafx.scene.paint.ImagePattern(img));
        }
    }

    private void cargarDatosPerfil() {
        if (usuarioActual != null) {
            txtNombre.setText(usuarioActual.getNombre());
            txtCorreo.setText(usuarioActual.getCorreo());

            if (usuarioActual.getRutaImagen() != null) {
                // Convert path to URI string for Image
                java.io.File imgFile = new java.io.File(usuarioActual.getRutaImagen());
                if (imgFile.exists()) {
                    actualizarAvatar(imgFile.toURI().toString());
                }
            }
        }
    }

    private void cargarConfiguracion() {
        if (usuarioActual == null)
            return;
        configuracion = configDAO.obtenerPorUsuario(usuarioActual.getIdUsuario());

        if (configuracion == null) {
            configuracion = new ConfiguracionNotificaciones();
            configuracion.setIdUsuario(usuarioActual.getIdUsuario());
        }

        chkEmail.setSelected(configuracion.isRecibirEmails());
        chkAlertasTareas.setSelected(configuracion.isAlertasTareas());
        chkAlertasComentarios.setSelected(configuracion.isAlertasComentarios());
        txtMinutosAntes.setText(String.valueOf(configuracion.getMinutosAntesVencimiento()));
    }

    private void cargarEstadisticas() {
        if (usuarioActual == null)
            return;
        try {
            List<Tarea> tareas = new TareaDAO().listarPorUsuario(usuarioActual.getIdUsuario());
            long completadas = tareas.stream().filter(t -> t.getEstado() == EstadoTarea.COMPLETED).count();
            long total = tareas.size();
            double tasa = total > 0 ? (double) completadas / total * 100 : 0;

            lblTareasCompletadas.setText(String.valueOf(completadas));
            lblTasaExito.setText(String.format("%.1f%%", tasa));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleGuardarPerfil() {
        if (usuarioActual == null)
            return;

        // Update basic info
        usuarioActual.setNombre(txtNombre.getText());
        usuarioActual.setCorreo(txtCorreo.getText());

        // Password change logic
        String passActual = txtPasswordActual.getText();
        String passNueva = txtPasswordNueva.getText();
        String passConfirmar = txtPasswordConfirmar.getText();

        if (!passNueva.isEmpty()) {
            if (!passNueva.equals(passConfirmar)) {
                mostrarAlerta(Alert.AlertType.ERROR, "Las contraseñas no coinciden.");
                return;
            }
            // In a real app, we should hash the input and compare with stored hash
            // For now, assuming simple check (or missing check for old password for
            // simplicity if not strictly required)
            if (!usuarioActual.getClave().equals(passActual)) {
                mostrarAlerta(Alert.AlertType.ERROR, "La contraseña actual es incorrecta.");
                return;
            }
            usuarioActual.setClave(passNueva); // Should be hashed
        }

        try {
            if (usuarioDAO.actualizar(usuarioActual)) {
                mostrarAlerta(Alert.AlertType.INFORMATION, "Perfil actualizado correctamente.");
                txtPasswordActual.clear();
                txtPasswordNueva.clear();
                txtPasswordConfirmar.clear();
            } else {
                mostrarAlerta(Alert.AlertType.ERROR, "No se pudo actualizar el perfil.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta(Alert.AlertType.ERROR, "Error de base de datos: " + e.getMessage());
        }
    }

    @FXML
    private void handleGuardarNotificaciones() {
        if (configuracion == null)
            return;

        configuracion.setRecibirEmails(chkEmail.isSelected());
        configuracion.setAlertasTareas(chkAlertasTareas.isSelected());
        configuracion.setAlertasComentarios(chkAlertasComentarios.isSelected());

        try {
            int minutos = Integer.parseInt(txtMinutosAntes.getText());
            configuracion.setMinutosAntesVencimiento(minutos);
        } catch (NumberFormatException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "El valor de minutos debe ser numérico.");
            return;
        }

        configDAO.guardar(configuracion);
        mostrarAlerta(Alert.AlertType.INFORMATION, "Preferencias guardadas.");
    }

    private void mostrarAlerta(Alert.AlertType tipo, String mensaje) {
        new Alert(tipo, mensaje).showAndWait();
    }
}
