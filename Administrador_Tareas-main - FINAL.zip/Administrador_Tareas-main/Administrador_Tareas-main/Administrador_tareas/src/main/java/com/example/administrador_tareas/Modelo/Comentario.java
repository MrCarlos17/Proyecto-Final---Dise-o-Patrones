package com.example.administrador_tareas.Modelo;

import java.time.LocalDateTime;

/**
 *
 * @author Carlos Arroyo
 */

public class Comentario {
    private Long idComentario;
    private Long idTarea;
    private Long idUsuario;
    private String contenido;
    private LocalDateTime fechaCreacion;

    public Comentario() {
    }

    public Comentario(Long idComentario, Long idTarea, Long idUsuario, String contenido, LocalDateTime fechaCreacion) {
        this.idComentario = idComentario;
        this.idTarea = idTarea;
        this.idUsuario = idUsuario;
        this.contenido = contenido;
        this.fechaCreacion = fechaCreacion;
    }

    public Long getIdComentario() {
        return idComentario;
    }

    public void setIdComentario(Long idComentario) {
        this.idComentario = idComentario;
    }

    public Long getIdTarea() {
        return idTarea;
    }

    public void setIdTarea(Long idTarea) {
        this.idTarea = idTarea;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    private String nombreUsuario;

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
}
