package com.example.administrador_tareas.Modelo;

/**
 *
 * @author Carlos Arroyo
 */

public enum PrioridadTarea {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}
