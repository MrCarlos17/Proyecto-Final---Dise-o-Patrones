package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.EstadoProyecto;
import com.example.administrador_tareas.Modelo.Proyecto;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Carlos Arroyo
 */

public class ProyectoDAO {

    public List<Proyecto> listarProyectos() {
        List<Proyecto> proyectos = new ArrayList<>();
        String sql = "SELECT p.*, e.nombre as nombre_equipo FROM proyectos p LEFT JOIN equipos e ON p.id_equipo = e.id_equipo";

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                proyectos.add(mapearProyecto(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return proyectos;
    }

    public Long insertar(Proyecto proyecto) throws SQLException {
        String sql = "INSERT INTO proyectos (nombre, codigo, descripcion, id_equipo, estado, fecha_creacion, fecha_actualizacion) "
                +
                "VALUES (?, ?, ?, ?, ?::estado_proyecto_enum, NOW(), NOW())";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, proyecto.getNombre());
            ps.setString(2, proyecto.getCodigo());
            ps.setString(3, proyecto.getDescripcion());
            if (proyecto.getIdEquipo() != null)
                ps.setLong(4, proyecto.getIdEquipo());
            else
                ps.setNull(4, Types.BIGINT);
            ps.setString(5, proyecto.getEstado().name());

            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0)
                throw new SQLException("Creating project failed, no rows affected.");

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    proyecto.setIdProyecto(generatedKeys.getLong(1));
                    return generatedKeys.getLong(1);
                } else {
                    throw new SQLException("Creating project failed, no ID obtained.");
                }
            }
        }
    }

    public boolean actualizar(Proyecto proyecto) throws SQLException {
        String sql = "UPDATE proyectos SET nombre = ?, codigo = ?, descripcion = ?, id_equipo = ?, estado = ?::estado_proyecto_enum, fecha_actualizacion = NOW() "
                +
                "WHERE id_proyecto = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, proyecto.getNombre());
            ps.setString(2, proyecto.getCodigo());
            ps.setString(3, proyecto.getDescripcion());
            if (proyecto.getIdEquipo() != null)
                ps.setLong(4, proyecto.getIdEquipo());
            else
                ps.setNull(4, Types.BIGINT);
            ps.setString(5, proyecto.getEstado().name());
            ps.setLong(6, proyecto.getIdProyecto());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminar(Long idProyecto) throws SQLException {
        // Soft delete could be implemented if schema supported it, but schema says
        // 'estado' can be ARCHIVADO.
        // Or we can delete if no tasks attached. For now, let's assume hard delete or
        // archive.
        // User request says "Archivar proyectos completos (cambia estado a ARCHIVADO)".
        // So 'eliminar' might not be requested, but useful.
        String sql = "DELETE FROM proyectos WHERE id_proyecto = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idProyecto);
            return ps.executeUpdate() > 0;
        }
    }

    public java.util.Optional<Proyecto> buscarPorId(Long idProyecto) {
        String sql = "SELECT * FROM proyectos WHERE id_proyecto = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idProyecto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return java.util.Optional.of(mapearProyecto(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return java.util.Optional.empty();
    }

    public List<Proyecto> listarPorEquipo(Long idEquipo) {
        List<Proyecto> proyectos = new ArrayList<>();
        String sql = "SELECT * FROM proyectos WHERE id_equipo = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    proyectos.add(mapearProyecto(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return proyectos;
    }

    private Proyecto mapearProyecto(ResultSet rs) throws SQLException {
        Proyecto p = new Proyecto();
        p.setIdProyecto(rs.getLong("id_proyecto"));
        p.setNombre(rs.getString("nombre"));
        p.setCodigo(rs.getString("codigo"));
        p.setDescripcion(rs.getString("descripcion"));
        p.setIdEquipo(rs.getObject("id_equipo") != null ? rs.getLong("id_equipo") : null);
        p.setEstado(EstadoProyecto.valueOf(rs.getString("estado")));
        p.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
        p.setFechaActualizacion(rs.getTimestamp("fecha_actualizacion").toLocalDateTime());
        try {
            p.setNombreEquipo(rs.getString("nombre_equipo"));
        } catch (SQLException e) {
            // Column might not exist in all queries (e.g. simple select)
            // Ignore or handle if strictly required
        }
        return p;
    }
}
