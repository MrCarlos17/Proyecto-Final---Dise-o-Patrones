package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.util.Duration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.CompletableFuture;

/**
 *
 * @author Carlos Arroyo
 */

public class InicioController implements Initializable {

    @FXML
    private Label lblHora;
    @FXML
    private Label lblFecha;
    @FXML
    private ComboBox<String> cmbZonaClima;
    @FXML
    private Label lblTemperatura;
    @FXML
    private Label lblCondicion;
    @FXML
    private Label lblHumedad;
    @FXML
    private ListView<String> listaTareasPendientes;
    @FXML
    private Label lblUsdPen;
    @FXML
    private Label lblEurPen;
    @FXML
    private Label lblActualizacionCambio;

    private final TareaDAO tareaDAO = new TareaDAO();
    private Usuario usuarioActual;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        iniciarReloj();
        configurarClima();
        cargarTipoCambio();
    }

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        cargarTareasPendientes();
    }

    private void iniciarReloj() {
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            LocalDateTime ahora = LocalDateTime.now(ZoneId.of("America/Lima"));
            lblHora.setText(ahora.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
            lblFecha.setText(ahora.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM")));
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void configurarClima() {
        cmbZonaClima.getItems().addAll("Chiclayo", "Lima", "Cusco", "Arequipa");
        cmbZonaClima.setValue("Chiclayo");
        cmbZonaClima.setOnAction(e -> cargarClima(cmbZonaClima.getValue()));
        cargarClima("Chiclayo");
    }

    private void cargarClima(String ciudad) {
        lblTemperatura.setText("Cargando...");
        lblCondicion.setText("...");

        CompletableFuture.runAsync(() -> {
            try {
                // Coordinates for Chiclayo (default)
                double lat = -6.77;
                double lon = -79.84;

                if ("Lima".equals(ciudad)) {
                    lat = -12.04;
                    lon = -77.04;
                } else if ("Cusco".equals(ciudad)) {
                    lat = -13.53;
                    lon = -71.96;
                } else if ("Arequipa".equals(ciudad)) {
                    lat = -16.40;
                    lon = -71.53;
                }

                String urlString = String.format(
                        "https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f&current_weather=true", lat,
                        lon);
                String json = fetchJson(urlString);

                // Simple JSON parsing
                int currentWeatherIndex = json.indexOf("\"current_weather\"");
                String temp = "0";
                if (currentWeatherIndex != -1) {
                    temp = extractJsonValue(json.substring(currentWeatherIndex), "temperature");
                }

                String finalTemp = temp;
                Platform.runLater(() -> {
                    lblTemperatura.setText(finalTemp + "°C");
                    lblCondicion.setText("Actualizado");
                    lblHumedad.setText(""); // Open-Meteo basic free tier might not give humidity in current_weather
                                            // easily without more parsing
                });

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    lblTemperatura.setText("Error");
                    lblCondicion.setText("Sin conexión");
                });
            }
        });
    }

    private void cargarTipoCambio() {
        CompletableFuture.runAsync(() -> {
            try {
                String json = fetchJson("https://open.er-api.com/v6/latest/USD");

                // Extract PEN rate (USD -> PEN)
                String penRateStr = extractJsonValue(json, "PEN");
                double penRate = Double.parseDouble(penRateStr);

                // Extract EUR rate (USD -> EUR) to calculate EUR -> PEN
                String eurRateStr = extractJsonValue(json, "EUR");
                double eurRate = Double.parseDouble(eurRateStr);

                double eurToPen = penRate / eurRate;

                Platform.runLater(() -> {
                    lblUsdPen.setText(String.format("S/ %.2f", penRate));
                    lblEurPen.setText(String.format("S/ %.2f", eurToPen));
                    lblActualizacionCambio.setText("Fuente: Open Exchange Rates");
                });

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    lblUsdPen.setText("S/ --.--");
                    lblEurPen.setText("S/ --.--");
                });
            }
        });
    }

    private void cargarTareasPendientes() {
        if (usuarioActual == null)
            return;

        try {
            List<Tarea> tareas = tareaDAO.listarPorUsuario(usuarioActual.getIdUsuario());

            listaTareasPendientes.getItems().clear();

            // Filter for pending tasks and take top 5
            tareas.stream()
                    .filter(t -> t.getEstado() == com.example.administrador_tareas.Modelo.EstadoTarea.PENDING)
                    .limit(5)
                    .forEach(t -> listaTareasPendientes.getItems().add(t.getTitulo()));

            if (listaTareasPendientes.getItems().isEmpty()) {
                listaTareasPendientes.getItems().add("No tienes tareas pendientes.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            listaTareasPendientes.getItems().add("Error al cargar tareas.");
        }
    }

    private String fetchJson(String urlString) throws Exception {
        System.out.println("Fetching URL: " + urlString);
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "Mozilla/5.0");

        int responseCode = conn.getResponseCode();
        System.out.println("Response Code: " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder content = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }
        in.close();
        System.out.println("Response Content: " + content.toString());
        return content.toString();
    }

    // Helper to extract value from JSON string (very basic regex-like search)
    private String extractJsonValue(String json, String key) {
        String search = "\"" + key + "\":";
        int start = json.indexOf(search);
        if (start == -1)
            return "0";

        start += search.length();
        int end = json.indexOf(",", start);
        if (end == -1)
            end = json.indexOf("}", start);

        return json.substring(start, end).trim();
    }
}
