package com.example.administrador_tareas.Modelo;

/**
 *
 * @author Carlos Arroyo
 */

public class ConfiguracionNotificaciones {
    private Long idConfiguracion;
    private Long idUsuario;
    private boolean recibirEmails;
    private boolean alertasTareas;
    private boolean alertasComentarios;
    private int minutosAntesVencimiento;

    public ConfiguracionNotificaciones() {
        // Defaults
        this.recibirEmails = true;
        this.alertasTareas = true;
        this.alertasComentarios = true;
        this.minutosAntesVencimiento = 30;
    }

    public Long getIdConfiguracion() {
        return idConfiguracion;
    }

    public void setIdConfiguracion(Long idConfiguracion) {
        this.idConfiguracion = idConfiguracion;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public boolean isRecibirEmails() {
        return recibirEmails;
    }

    public void setRecibirEmails(boolean recibirEmails) {
        this.recibirEmails = recibirEmails;
    }

    public boolean isAlertasTareas() {
        return alertasTareas;
    }

    public void setAlertasTareas(boolean alertasTareas) {
        this.alertasTareas = alertasTareas;
    }

    public boolean isAlertasComentarios() {
        return alertasComentarios;
    }

    public void setAlertasComentarios(boolean alertasComentarios) {
        this.alertasComentarios = alertasComentarios;
    }

    public int getMinutosAntesVencimiento() {
        return minutosAntesVencimiento;
    }

    public void setMinutosAntesVencimiento(int minutosAntesVencimiento) {
        this.minutosAntesVencimiento = minutosAntesVencimiento;
    }
}
