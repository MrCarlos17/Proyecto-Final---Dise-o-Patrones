package com.example.administrador_tareas.Modelo;

/**
 *
 * @author Carlos Arroyo
 */

public enum EstadoProyecto {
    ACTIVO,
    ARCHIVADO
}
