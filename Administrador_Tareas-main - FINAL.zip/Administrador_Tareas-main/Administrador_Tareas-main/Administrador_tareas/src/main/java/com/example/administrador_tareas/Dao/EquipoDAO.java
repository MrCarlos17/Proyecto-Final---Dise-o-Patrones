package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.Equipo;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Carlos Arroyo
 */

public class EquipoDAO {

    public List<Equipo> listarEquipos() {
        List<Equipo> equipos = new ArrayList<>();
        String sql = "SELECT * FROM equipos";

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Equipo equipo = new Equipo();
                equipo.setIdEquipo(rs.getLong("id_equipo"));
                equipo.setNombre(rs.getString("nombre"));
                equipo.setDescripcion(rs.getString("descripcion"));
                equipo.setColorTag(rs.getString("color_tag"));
                equipo.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                equipo.setFechaActualizacion(rs.getTimestamp("fecha_actualizacion").toLocalDateTime());
                equipos.add(equipo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return equipos;
    }

    public Long insertar(Equipo equipo) throws SQLException {
        String sql = "INSERT INTO equipos (nombre, descripcion, color_tag, fecha_creacion, fecha_actualizacion) VALUES (?, ?, ?, NOW(), NOW())";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, equipo.getNombre());
            ps.setString(2, equipo.getDescripcion());
            ps.setString(3, equipo.getColorTag());

            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0)
                throw new SQLException("Creating team failed, no rows affected.");

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    equipo.setIdEquipo(generatedKeys.getLong(1));
                    return generatedKeys.getLong(1);
                } else {
                    throw new SQLException("Creating team failed, no ID obtained.");
                }
            }
        }
    }

    public boolean actualizar(Equipo equipo) throws SQLException {
        String sql = "UPDATE equipos SET nombre = ?, descripcion = ?, color_tag = ?, fecha_actualizacion = NOW() WHERE id_equipo = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, equipo.getNombre());
            ps.setString(2, equipo.getDescripcion());
            ps.setString(3, equipo.getColorTag());
            ps.setLong(4, equipo.getIdEquipo());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean agregarMiembro(Long idEquipo, Long idUsuario) throws SQLException {
        // Assuming a table miembros_equipo exists. If not, this will fail and I'll
        // debug.
        String sql = "INSERT INTO miembros_equipo (id_equipo, id_usuario, fecha_union) VALUES (?, ?, NOW())";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idEquipo);
            ps.setLong(2, idUsuario);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminarMiembro(Long idEquipo, Long idUsuario) throws SQLException {
        String sql = "DELETE FROM miembros_equipo WHERE id_equipo = ? AND id_usuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idEquipo);
            ps.setLong(2, idUsuario);
            return ps.executeUpdate() > 0;
        }
    }

    // Need to import Usuario
    public List<com.example.administrador_tareas.Modelo.Usuario> listarMiembros(Long idEquipo) {
        List<com.example.administrador_tareas.Modelo.Usuario> miembros = new ArrayList<>();
        String sql = "SELECT u.* FROM usuarios u JOIN miembros_equipo me ON u.id_usuario = me.id_usuario WHERE me.id_equipo = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    com.example.administrador_tareas.Modelo.Usuario usuario = new com.example.administrador_tareas.Modelo.Usuario();
                    usuario.setIdUsuario(rs.getLong("id_usuario"));
                    usuario.setNombre(rs.getString("nombre"));
                    usuario.setCorreo(rs.getString("correo"));
                    // Populate other fields if needed
                    miembros.add(usuario);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return miembros;
    }

    public List<Equipo> listarEquiposPorUsuario(Long idUsuario) {
        List<Equipo> equipos = new ArrayList<>();
        String sql = "SELECT e.* FROM equipos e JOIN miembros_equipo me ON e.id_equipo = me.id_equipo WHERE me.id_usuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Equipo equipo = new Equipo();
                    equipo.setIdEquipo(rs.getLong("id_equipo"));
                    equipo.setNombre(rs.getString("nombre"));
                    equipo.setDescripcion(rs.getString("descripcion"));
                    equipo.setColorTag(rs.getString("color_tag"));
                    equipo.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                    equipo.setFechaActualizacion(rs.getTimestamp("fecha_actualizacion").toLocalDateTime());
                    equipos.add(equipo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return equipos;
    }
}
